﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelReservationSystem.DTOs
{
    public class CountryDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}