﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelReservationSystem.Hidden
{
    public static class AdminCredentials
    {
        // TODO: To log in to the app as administrator use this credentials
        // To create new admin you must assign user to CanManageHotels role

        public static string Login = "admin@admin.com";
        public static string Password = "Admin1!";
    }
}