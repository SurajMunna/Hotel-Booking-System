﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelReservationSystem.Hidden
{
	public static class FacebookData
	{
        // TODO: Go to facebook developer page https://developers.facebook.com/
        // Register or log in
        // My Apps -> Add new app (Web)
        // Paste your app credentials here

        public static string AppId = "";
        public static string AppSecret = "";
    }
}